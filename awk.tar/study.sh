#! /bin/bash

# https://awk.readthedocs.io/en/latest/chapter-one.html
# http://www.runoob.com/linux/linux-comm-awk.html
# http://www.ruanyifeng.com/blog/2018/11/awk.html

# 单引号内的部分是一个完整的 awk 程序， 包含单个模式-动作。
# 其中 模式 和 动作都是可选的
# awk '$3 > 0 {print $1, $2*$3}' emp.data

# 可以将 awk 程序单独写在一个文件，其中 -f 选项指示 awk 从文件中获取程序
# awk -f profile option_list_of_input_file

# 简单输出
# $1, $3, 表示第1个字段， 第3个字段
# $0 表示输出整行
# NF 当前行的字段数
# NR 行数
# awk '{print $1, $3}' emp.data

# 高级输出 printf
# printf(format, value, value2, ..., valuen)
# awk '{printf("%6.2f    %s\n", $2*$3, $0)}' emp.data | sort

# 选择
# awk '$2*$3 > 50 {printf("$%.2f for %s\n", $2*$3, $1)}' emp.data

# awk '/susie/ {print $0}' emp.data


# 组合
# awk '$2 >= 4 || $3 >= 20 {print}' emp.data

# BEGIN 与 END
# 特殊模式 BEGIN 用于匹配第一个输入文件的第一行之前的位置
# END 用于匹配处理过的最后一个文件的最后一行的位置
# awk 'BEGIN {print "Name   RATE   HOURS"; print ""} { print }'  emp.data

# 计数
# 统计第三个字段超过15的行， emp变量默认初始值为0
# awk '$3 > 15 {emp = emp + 1}
# END {print emp, "employees worked more than 15 hours"}' emp.data

# awk 'END {print NR, "employees"}' emp.data

awk '{pay = pay + $2*$3}
END {print NR, "employees"
     print "total pay is", pay
     print "average pay is", pay/NR
     }' emp.data

echo ""

awk '$2 > maxrate {maxrate = $2; maxemp = $1}
END {print "hightest hourly rate:", maxrate, "for", maxemp}' emp.data

echo ""
awk '{print $1, length($1)}' emp.data

echo ""
awk '{print $1, "->",  tolower($1)}' emp.data

echo ""
awk '{print $1, "->", toupper($1)}' emp.data

echo ""
awk '{print "generate random number ", rand()}' emp.data

echo ""
awk '$2 > 6 {n = n + 1; pay = pay + $2*$3}
END { 
	if (n > 0)
		print n, "emplyees, total pay is", pay,
		"average pay is", pay/n
    else
		print "no emplyees are paid more than $6/hour"
   }' emp.data


# 反转 - 按行逆序打印输入
echo ""
awk '
{ line[NR] = $0}
END {i = NR
while (i > 0) {
	print line[i]
	i = i - 1
    }
}' emp.data


echo ""
awk '
{ line[NR] = $0 }
END { for (i = NR; i > 0; i = i - 1)
	print line[i]
}' emp.data

